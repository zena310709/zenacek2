import tkinter as tk
from tkinter import messagebox, ttk
import random
import json
import os

# Функция для генерации пароля
def generate_password():
    length = length_scale.get()
    include_digits = digit_var.get()
    include_uppercase = uppercase_var.get()
    include_special = special_var.get()
    
    # Условия для включения символов
    characters = ""
    if include_digits:
        characters += "0123456789"
    if include_uppercase:
        characters += "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    characters += "abcdefghijklmnopqrstuvwxyz"  # Всегда добавляем строчные буквы
    if include_special:
        characters += "!@#$%^&*()_+-=[]{}|;:,.<>?/"
    
    if not characters:
        messagebox.showerror("Ошибка", "Нужно выбрать хотя бы один тип символов!")
        return

    password = ''.join(random.choice(characters) for _ in range(length))
    
    # Сохранение сгенерированного пароля в историю
    history.append(password)
    update_history_table()
    save_history()

# Функция для обновления таблицы истории
def update_history_table():
    for row in history_tree.get_children():
        history_tree.delete(row)
    for password in history:
        history_tree.insert('', 'end', values=(password,))

# Функция для сохранения истории в файл
def save_history():
    with open("history.json", "w") as history_file:
        json.dump(history, history_file)

# Функция для загрузки истории из файла
def load_history():
    global history
    if os.path.exists("history.json"):
        with open("history.json", "r") as history_file:
            history = json.load(history_file)
            update_history_table()

# Инициализируем переменные и историю
history = []
load_history()

# Создаем главную панель
root = tk.Tk()
root.title("Генератор случайных паролей")

# Ползунок длины пароля
length_scale = tk.Scale(root, from_=4, to=20, orient='horizontal', label='Длина пароля')
length_scale.set(10)  # Устанавливаем значение по умолчанию
length_scale.pack()

# Чекбоксы для выбора символов
digit_var = tk.BooleanVar()
uppercase_var = tk.BooleanVar()
special_var = tk.BooleanVar()

tk.Checkbutton(root, text='Цифры', variable=digit_var).pack()
tk.Checkbutton(root, text='Буквы в верхнем регистре', variable=uppercase_var).pack()
tk.Checkbutton(root, text='Специальные символы', variable=special_var).pack()

# Кнопка генерации
generate_button = tk.Button(root, text='Сгенерировать пароль', command=generate_password)
generate_button.pack()

# Таблица истории
history_tr
Женя Чекмарева
Женя Чекмарева
50м

ee = ttk.Treeview(root, columns=("Пароль",), show="headings")
history_tree.heading("Пароль", text="Пароль")
history_tree.pack()

root.mainloop()